package com.example.mainactivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login_form extends AppCompatActivity {

    EditText txtEmail, txtPassword;
    Button btn_login1, btn_signupForm ,btn_authentication;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_login_form );
        getSupportActionBar().setTitle( "Login Form" );

        txtEmail = findViewById( R.id.txt_email );
        txtPassword = findViewById( R.id.txt_password );
        btn_login1 = findViewById( R.id.btn_login );
        btn_signupForm = findViewById( R.id.btn_register );
        btn_authentication=findViewById( R.id.btn_authentication );


        firebaseAuth = FirebaseAuth.getInstance();

        btn_login1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = txtEmail.getText().toString().trim();
                String password = txtPassword.getText().toString().trim();


                if (TextUtils.isEmpty( email )) {

                    Toast.makeText( Login_form.this, "Please enter Email", Toast.LENGTH_SHORT ).show();
                    return;
                }
                if (TextUtils.isEmpty( password )) {

                    Toast.makeText( Login_form.this, "Please enter Password", Toast.LENGTH_SHORT ).show();
                    return;
                }
                if (password.length() < 6) {

                    Toast.makeText( Login_form.this, "password too short", Toast.LENGTH_SHORT ).show();
                }


                firebaseAuth.signInWithEmailAndPassword( email, password )
                        .addOnCompleteListener( Login_form.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText( Login_form.this,"Login success",Toast.LENGTH_SHORT ).show();
                                    startActivity( new Intent( getApplicationContext(), MainActivity.class ) );


                                } else {

                                    Toast.makeText( Login_form.this, "Login Failed or User not Available ", Toast.LENGTH_SHORT ).show();

                                }

                                // ...
                            }
                        } );

            }
        } );


        /*btn_login1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent( getApplicationContext(),Login_form.class ) );
            }
        } );*/

        btn_signupForm.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent( getApplicationContext(),Signup_Form.class ) );
            }
        } );

        btn_authentication.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent( getApplicationContext() ,LoginActivity.class) );
            }
        } );


    }

    /*public void btn_signupForm(View view) {
        startActivity( new Intent( getApplicationContext(), Signup_Form.class ) );
    }*/


/*    public void btn_login1(View view) {
        startActivity( new Intent( getApplicationContext(), MainActivity.class ) );

    }*/
}
