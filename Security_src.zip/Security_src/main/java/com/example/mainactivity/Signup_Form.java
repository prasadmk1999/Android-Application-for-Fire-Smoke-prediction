package com.example.mainactivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Signup_Form extends AppCompatActivity {

    EditText txtEmail,txtPassword,txt_conformpass;
    Button btn_register1;
    TextView txtlog;
    ProgressBar progressBar;
    private FirebaseAuth firebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_signup__form );
        getSupportActionBar().setTitle( "SignUp Form" );

        txtEmail=findViewById( R.id.txt_email );
        txtPassword=findViewById( R.id.txt_password );
        btn_register1=findViewById( R.id.btn_register );
        txt_conformpass=findViewById( R.id.txt_conformpass);
        txtlog=findViewById( R.id.txt_log );
        //progressBar =findViewById( R.id.progressBar);

        firebaseAuth=FirebaseAuth.getInstance();

        if(firebaseAuth.getCurrentUser()!=null)
        {
            startActivity( new Intent( getApplicationContext(),MainActivity.class ) );
            finish();
        }

        btn_register1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=txtEmail.getText().toString().trim();
                String password=txtPassword.getText().toString().trim();
                String confirmPassword=txt_conformpass.getText().toString().trim();


                if(TextUtils.isEmpty(email)){

                    Toast.makeText( Signup_Form.this,"Please enter Email",Toast.LENGTH_SHORT ).show();
                    return;
                }
                if(TextUtils.isEmpty(password)){

                    Toast.makeText( Signup_Form.this,"Please enter Password",Toast.LENGTH_SHORT ).show();
                    return;
                }
                if(TextUtils.isEmpty(confirmPassword)){

                    Toast.makeText( Signup_Form.this,"Please enter  Correct Password",Toast.LENGTH_SHORT ).show();
                    return;
                }
                if(password.length()<6){

                    Toast.makeText( Signup_Form.this,"password too short",Toast.LENGTH_SHORT ).show();
                }
                 if(password.equals(confirmPassword)){
                     Toast.makeText( Signup_Form.this," Both Password Matches",Toast.LENGTH_SHORT ).show();
                 }
                 else{
                     Toast.makeText( Signup_Form.this,"Incorrect password entered !",Toast.LENGTH_SHORT ).show();
                 }


               if(password.equals( confirmPassword )){

                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener( Signup_Form.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    //progressBar.setVisibility( View.GONE);
                                    if (task.isSuccessful()) {
                                        Toast.makeText( Signup_Form.this ,"Registration successfully",Toast.LENGTH_SHORT ).show();
                                        startActivity( new Intent( getApplicationContext(),MainActivity.class ) );
                                        finish();
                                    }
                                    else {
                                        Toast.makeText( Signup_Form.this,"SignUp Failed",Toast.LENGTH_SHORT ).show();
                                    }
                                    // ...
                                }
                            });

                }

                txtlog.setOnClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity( new Intent( getApplicationContext(),Login_form.class ) );
                    }
                } );

            }

        } );





    }

   /*public void txtlog(View view) {
        startActivity( new Intent( getApplicationContext(), Login_form.class ) );

    }*/
}
