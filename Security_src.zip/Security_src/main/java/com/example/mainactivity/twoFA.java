package com.example.mainactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class twoFA extends AppCompatActivity {

    private Button Next;
    private Button Clear;
    private EditText Phoneno;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_two_f );
        Next = (Button) findViewById( R.id.button1 );
        Phoneno = (EditText) findViewById( R.id.editText1 );
        Clear = findViewById( R.id.button2 );


        Next.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent( twoFA.this, DashBoardActivity.class );
                startActivity( intent );
                Toast.makeText( twoFA.this, "You Clicked on Next button..!!", Toast.LENGTH_SHORT ).show();

            }
        } );

        Clear.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Phoneno.getText().clear();
                Toast.makeText( twoFA.this, "You Clicked on Clear button..!!", Toast.LENGTH_SHORT ).show();

            }
        } );
    }


}